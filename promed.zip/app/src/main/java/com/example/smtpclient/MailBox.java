package com.example.smtpclient;

import java.util.Scanner;

public class MailBox {
    String[] atributes;
    String name;
    int id;


    public MailBox(){

    }
    public MailBox(String data){/*
        Scanner linea = new Scanner(data).useDelimiter(" ");
        Scanner s;
        while(linea.hasNext()){
            s = new Scanner(linea.next()).useDelimiter(" ");
            if(s.)
        }*/
    }
}
